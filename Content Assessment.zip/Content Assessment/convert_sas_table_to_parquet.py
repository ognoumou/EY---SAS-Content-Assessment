# -*- coding: utf-8 -*-
"""
Created on Fri Apr 14 11:11:11 2023

@author: EY283FA
"""

import pandas as pd
import re
import os

root = r'C:\SAEED\Sun Life\Demo Sample Sets\Set 1\Sample Data Sets'

filelist = []
for path, subdirs, files in os.walk(root):
    for name in files:
        if name.endswith('.sas7bdat'):
            filelist.append(os.path.join(path,name))


# Decoding the df
def decode_string(x):
    if isinstance(x, bytes):
        return x.decode('latin-1')
    else:
        return x


for item in filelist:
    try:
        tb = pd.read_sas(item)
        tb[tb.columns] = tb[tb.columns].applymap(decode_string)
        tb.to_parquet(item.replace('.sas7bdat','.parquet'))
    except Exception as e:
        print('Error in reading the SAS table!')
        print(e)