


import pandas as pd
import os

df = pd.DataFrame()

filelist = []
main_directory = r'C:\SAEED\downloads\02--Quantitative Assessment\01--Output of python script\LSRD_EPI'

main_folders = [name for name in os.listdir(main_directory)
                if os.path.isdir(os.path.join(main_directory, name))]

main_folders_fullpath = [os.path.join(main_directory,x) for x in main_folders]

data = pd.DataFrame()
for item in [a for a in main_folders_fullpath]:
    for path, subdirs, files in os.walk(item):
        for f in files:
            if f.startswith('sas_programs_proc_list'):
                # if f.startswith('sas_tables_sim_') == False:
                print(os.path.join(path,f))
                df = pd.read_csv(os.path.join(path,f))
                if df.shape[0] > 0:
                    print(f)
                    data = data.append(df)


data.to_csv(r'C:\SAEED\downloads\02--Quantitative Assessment\01--Output of python script/EPI_proc_list.csv')